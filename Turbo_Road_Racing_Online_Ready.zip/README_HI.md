# Turbo Road Racing — Mobile Edition

## Included
- `index.html`: playable canvas racing game with mobile touch controls, traffic, speed, distance, coins, nitro, pause and restart.
- `server.js`: Express + Socket.IO server, rooms and live player state broadcasting.
- `package.json`: dependencies and start command.

## Play offline on your phone
1. Extract the ZIP.
2. Open `index.html` in a mobile browser or an HTML editor app that can preview HTML.
3. Tap **OFFLINE RACE**.
4. If the preview app blocks local files or scripts, use a local HTML preview feature or deploy the folder as a website.

## Host online using only your phone
You need a GitHub account and a Render account. The game must be deployed as a **Web Service**, not a Static Site, because it uses a Node server and Socket.IO.

1. Extract this ZIP on your phone.
2. On GitHub, create a new repository named `turbo-road-racing`.
3. Upload all three files (`index.html`, `server.js`, `package.json`) to the repository root. Do not upload the ZIP as the only file.
4. Open Render Dashboard in your phone browser and sign in with GitHub.
5. Tap **New + → Web Service**, then select `turbo-road-racing`.
6. Set:
   - Runtime/Language: `Node`
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Instance plan: choose an available plan. Free services may sleep after inactivity.
7. Tap **Create Web Service** and wait for deployment to finish.
8. Open the `https://YOUR-SERVICE.onrender.com` URL Render gives you. The game page should load.
9. On your phone, tap **ONLINE ROOM**, enter a room code such as `TURBO1`, then tap **JOIN ROOM**.
10. Your friend opens the exact same URL on another device, chooses the same room code, and taps **JOIN ROOM**.

## Important limitations
- This is a starter prototype, not a finished commercial/Play Store release.
- Online mode currently shares player positions in a room and draws other players as ghost cars. It does not yet have synchronized race starts, server-authoritative collisions, accounts, anti-cheat, matchmaking, voice chat or persistent leaderboards.
- The game page loads Socket.IO from the same deployed server. A local `file://` page can play offline but cannot join an online room; use the hosted HTTPS URL for multiplayer.
- Keep the service URL private to your group if you want to avoid unwanted players. Never put passwords or secret keys in client-side code.
- Test the game on both phones after deployment. A free hosting service can take a little while to wake up after inactivity.
