const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true, methods: ["GET", "POST"] },
  pingInterval: 25000,
  pingTimeout: 20000
});

app.use(express.static(path.join(__dirname)));
app.get("/health", (_req, res) => res.json({ ok: true, game: "Turbo Road Racing" }));

const rooms = new Map();
const cleanText = (value, max = 14) => String(value || "").replace(/[<>]/g, "").trim().slice(0, max);

function roomPlayers(room) {
  const ids = rooms.get(room);
  if (!ids) return [];
  return [...ids].map(id => {
    const s = io.sockets.sockets.get(id);
    return s && s.data.player ? { id, ...s.data.player } : null;
  }).filter(Boolean);
}
function broadcastRoom(room) {
  io.to(room).emit("roomUpdate", { room, players: roomPlayers(room) });
}

io.on("connection", socket => {
  socket.on("joinRoom", payload => {
    const room = cleanText(payload && payload.room, 12).toUpperCase() || "TURBO1";
    const name = cleanText(payload && payload.name, 14) || "Racer";
    if (socket.data.room) {
      socket.leave(socket.data.room);
      const old = rooms.get(socket.data.room);
      if (old) { old.delete(socket.id); if (!old.size) rooms.delete(socket.data.room); else broadcastRoom(socket.data.room); }
    }
    if (!rooms.has(room)) rooms.set(room, new Set());
    rooms.get(room).add(socket.id);
    socket.data.room = room;
    socket.data.player = { name, x: 0, speed: 0, dist: 0, coins: 0, updatedAt: Date.now() };
    socket.join(room);
    socket.emit("joined", { room, players: rooms.get(room).size });
    broadcastRoom(room);
  });

  socket.on("playerUpdate", data => {
    const room = socket.data.room;
    if (!room || !socket.data.player || !data || typeof data !== "object") return;
    const num = (v, lo, hi) => Math.max(lo, Math.min(hi, Number.isFinite(Number(v)) ? Number(v) : 0));
    socket.data.player = {
      name: socket.data.player.name,
      x: num(data.x, -1, 1),
      speed: num(data.speed, 0, 320),
      dist: num(data.dist, 0, 100000000),
      coins: Math.floor(num(data.coins, 0, 1000000)),
      updatedAt: Date.now()
    };
    broadcastRoom(room);
  });

  socket.on("disconnect", () => {
    const room = socket.data.room;
    if (!room) return;
    const ids = rooms.get(room);
    if (ids) { ids.delete(socket.id); if (!ids.size) rooms.delete(room); else broadcastRoom(room); }
  });
});

const PORT = process.env.PORT || 10000;
server.listen(PORT, "0.0.0.0", () => console.log(`Turbo Road Racing listening on ${PORT}`));
